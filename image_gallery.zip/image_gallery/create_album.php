<?php
$con=mysqli_connect("localhost","root","","multiple_uploads");
		// Check connection
		if (mysqli_connect_errno())
		  {
		  echo "Failed to connect to MySQL: " . mysqli_connect_error();
		  }
		  
if(!empty($_FILES['file']) && !empty($_POST['title'])){
	foreach($_FILES['file']['name'] as $key => $name){
		$size = $_FILES['file']['size'][$key];
		$extension = explode('.', $name);
		$extension = end($extension);
		$random_name = rand();
		$images = $random_name.".".$extension;
		$url = "files/".$images;
		$title = $_POST['title'];
		if($_FILES['file']['error'][$key] == 0 && move_uploaded_file($_FILES['file']['tmp_name'][$key], "files/{$images}")){
			$uploaded[]=$images;
			mysqli_query($con, "INSERT INTO images (name,url,title)VALUES ('".$name."','".$url."','".$title."')");
		}
	}
	mysqli_query($con, "INSERT INTO folders (title) VALUES ('$title')");
}else{
		$message = "All field is required";
	}
?>
<html>
<head>
<title>Upload Picture</title>
<link href="css/style.css" rel="stylesheet" type="text/css">
</head>
<body">

<div id="container">
	<div class="header">
    	<h1>My Album</h1>
    </div>
    <div class="content">
        <div>
            <form action="" method="post" enctype="multipart/form-data">
                <div>
                    Upload Picture: <input type="file" name="file[]" id="file" multiple="multiple" />
                    Title : <input type="text" name="title" id="title">
                    <input type="submit" id="submit" value="Upload"/>
                </div>
            </form>
            <?php if(isset($message)){echo "<h2>$message</h2>";} ?>
        </div>
			<?php
                if(!empty($uploaded)){
                    foreach($uploaded as $images){
                        
                        echo "<div class='photo_holder'><a href='".$url."'><img src='files/".$images."' height='200' width='200'></br> </a></div>";
                    }
                }
            ?>
    </div>
    <h5><a href="index.php">Done</a></h5>
    
</div>
</body>
</html>