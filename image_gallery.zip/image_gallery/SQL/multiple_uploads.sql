-- phpMyAdmin SQL Dump
-- version 4.0.4
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jun 27, 2014 at 07:16 AM
-- Server version: 5.6.12-log
-- PHP Version: 5.4.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `multiple_uploads`
--
CREATE DATABASE IF NOT EXISTS `multiple_uploads` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `multiple_uploads`;

-- --------------------------------------------------------

--
-- Table structure for table `folders`
--

CREATE TABLE IF NOT EXISTS `folders` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `title` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=23 ;

--
-- Dumping data for table `folders`
--

INSERT INTO `folders` (`id`, `title`) VALUES
(17, 'cars'),
(18, 'Cellphones'),
(19, 'ranchus'),
(20, 'rat rod'),
(21, 'wallpaper'),
(22, 'Lebron');

-- --------------------------------------------------------

--
-- Table structure for table `images`
--

CREATE TABLE IF NOT EXISTS `images` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `url` varchar(255) NOT NULL,
  `title` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=228 ;

--
-- Dumping data for table `images`
--

INSERT INTO `images` (`id`, `name`, `url`, `title`) VALUES
(172, '1.jpg', 'files/7622.jpg', 'cars'),
(173, '2.jpg', 'files/12679.jpg', 'cars'),
(174, '3.jpg', 'files/26804.jpg', 'cars'),
(175, '4.jpg', 'files/7389.jpg', 'cars'),
(176, '5.jpg', 'files/20562.jpg', 'cars'),
(177, '6.jpg', 'files/24355.jpg', 'cars'),
(178, '7.jpg', 'files/23584.jpg', 'cars'),
(179, '8.jpg', 'files/10713.jpg', 'cars'),
(180, '9.jpg', 'files/8094.jpg', 'cars'),
(181, '10.jpg', 'files/19071.jpg', 'cars'),
(182, '11.jpg', 'files/6732.jpg', 'cars'),
(183, '12.jpg', 'files/2709.jpg', 'cars'),
(184, '13.jpg', 'files/6058.jpg', 'cars'),
(185, '14.jpg', 'files/3995.jpg', 'cars'),
(186, '15.jpg', 'files/3896.jpg', 'cars'),
(187, 'c1.jpg', 'files/15121.jpg', 'Cellphones'),
(188, 'c2.jpg', 'files/1142.jpg', 'Cellphones'),
(189, 'c3.jpg', 'files/2679.jpg', 'Cellphones'),
(190, 'c4.jpg', 'files/26340.jpg', 'Cellphones'),
(191, 'c6.jpg', 'files/30541.jpg', 'Cellphones'),
(192, 'c7.jpg', 'files/29186.jpg', 'Cellphones'),
(193, 'r1.jpg', 'files/11884.jpg', 'ranchus'),
(194, 'r2.jpg', 'files/23605.jpg', 'ranchus'),
(195, 'r3.jpg', 'files/6346.jpg', 'ranchus'),
(196, 'r4.jpg', 'files/19003.jpg', 'ranchus'),
(197, 'r5.jpg', 'files/17752.jpg', 'ranchus'),
(198, 'r6.jpg', 'files/1713.jpg', 'ranchus'),
(199, 'r7.jpg', 'files/30614.jpg', 'ranchus'),
(200, 'r8.jpg', 'files/20247.jpg', 'ranchus'),
(201, 'r9.jpg', 'files/24324.jpg', 'ranchus'),
(202, 'r10.jpg', 'files/23789.jpg', 'ranchus'),
(203, 'r11.jpg', 'files/30498.jpg', 'ranchus'),
(204, 'r12.jpg', 'files/17843.jpg', 'ranchus'),
(205, 'r13.jpg', 'files/26480.jpg', 'ranchus'),
(206, 'rat1.jpg', 'files/10965.jpg', 'rat rod'),
(207, 'rat2.jpg', 'files/21226.jpg', 'rat rod'),
(208, 'rat3.jpg', 'files/18907.jpg', 'rat rod'),
(209, 'rat4.jpg', 'files/23672.jpg', 'rat rod'),
(210, 'rat5.jpg', 'files/8017.jpg', 'rat rod'),
(211, 'rat6.jpg', 'files/13238.jpg', 'rat rod'),
(212, 'rat7.jpg', 'files/10423.jpg', 'rat rod'),
(213, 'rat8.jpg', 'files/18468.jpg', 'rat rod'),
(214, 'n1.jpg', 'files/15593.jpg', 'wallpaper'),
(215, 'n2.jpg', 'files/7534.jpg', 'wallpaper'),
(216, 'n3.jpg', 'files/15375.jpg', 'wallpaper'),
(217, 'n4.jpg', 'files/21660.jpg', 'wallpaper'),
(218, 'n5.jpg', 'files/16037.jpg', 'wallpaper'),
(219, 'n6.jpg', 'files/8826.jpg', 'wallpaper'),
(220, 'n7.jpg', 'files/2603.jpg', 'wallpaper'),
(221, 'n8.jpg', 'files/7816.jpg', 'wallpaper'),
(222, 'n9.jpg', 'files/8225.jpg', 'wallpaper'),
(223, 'n10.jpg', 'files/27718.jpg', 'wallpaper'),
(224, 'lebron1.jpg', 'files/7687.jpg', 'Lebron'),
(225, 'lebron2.jpg', 'files/6964.jpg', 'Lebron'),
(226, 'lebron3.jpg', 'files/7517.jpg', 'Lebron'),
(227, 'lebron4.jpg', 'files/1746.jpg', 'Lebron');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
