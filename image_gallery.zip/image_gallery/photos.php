<html>
<head>
<title>Upload Picture</title>
<link href="css/style.css" rel="stylesheet" type="text/css">
</head>
<body">
<div id="container">
	<div class="content">
            <?php
                $con=mysqli_connect("localhost","root","","multiple_uploads");
                    // Check connection
                    if (mysqli_connect_errno())
                      {
                      echo "Failed to connect to MySQL: " . mysqli_connect_error();
                      }
				if(isset($_GET['title'])){
					$title = $_GET['title'];
			?>
            <h6><?php echo $title; ?></h6>
            <?php
                $result = mysqli_query($con, "SELECT * FROM images WHERE title = '$title'");
                while($row = mysqli_fetch_array($result)){
                    echo "<div class='photo_holder'>";
                    echo "<a href='".$row['url']."'><img src='" . $row['url'] . "' width='225px' height='225px' /></a>";
					echo "</div>";
					
                }
				}
           ?>
	</div>
    <h5><a href="index.php">BACK</a></h5>
</div>
</body>
</html>